from django.apps import AppConfig


class DjangofilteringConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'snippets'
